import requests
from flask import Flask, jsonify

app = Flask(__name__)

@app.route('/orders/<int:order_id>', methods=['GET'])
def get_order(order_id):
    try:
        # Call product-service
        product = requests.get(f'http://product-service:5001/products/{order_id}').json()
        return jsonify({"order_id": order_id, "product": product})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5002)
 
