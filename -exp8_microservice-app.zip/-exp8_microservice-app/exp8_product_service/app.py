from flask import Flask, jsonify

app = Flask(__name__)

products = {
    1: {"name": "Laptop", "price": 1200},
    2: {"name": "Mouse", "price": 25},
}

@app.route('/products/<int:product_id>')
def get_product(product_id):
    product = products.get(product_id)
    if product:
        return jsonify(product)
    return jsonify({"error": "Product not found"}), 404

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5001)
 
